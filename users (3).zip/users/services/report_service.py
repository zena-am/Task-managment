from django.db import transaction
from rest_framework.exceptions import PermissionDenied, ValidationError

from users.constants import create_activity_log
from users.models import LeaveTaskAction, Notification, ProjectRole
from users.errors.exceptions import BaseAppException

from datetime import timedelta
from django.utils import timezone

class ReportService:


    @staticmethod
    def update_technical_report(report, serializer, user):
        report = serializer.save()

        create_activity_log(
            user=user,
            action="REPORT_DRAFT_UPDATED",
            action_id=report.id,
            changes={
                "subject_name": user.username,
                "target_title": report.task.title,
                "reason": f"Report for task '{report.task.title}' was updated by {user.username}.",
                "is_by_admin": False
            }
        )

        return report

    @staticmethod
    def delete_technical_report(report, user):
        create_activity_log(
            user=user,
            action="REPORT_DELETED",
            action_id=report.id,
            changes={
                "subject_name": user.username,
                "target_title": report.task.title,
                "reason": f"Report for task '{report.task.title}' was deleted by {user.username}.",
                "is_by_admin": False
            }
        )

        report.delete()
    @staticmethod
    def save_technical_report_draft(serializer, user):
        task = serializer.validated_data.get("task")

        latest_report = task.technical_reports.order_by("-created_at").first()

        if latest_report:
            if latest_report.status == "SUBMITTED":

                raise BaseAppException(
                detail="A submitted report is already awaiting manager review.",
                code="REPORT_ALREADY_SUBMITTED",
                status_code=400)

            if latest_report.status == "APPROVED":
                raise BaseAppException(
            detail="This task already has an approved report.",
            code="REPORT_ALREADY_APPROVED",
            status_code=400
)

            if latest_report.status == "DRAFT":
                raise BaseAppException(
    detail="A draft report already exists for this task.",
    code="REPORT_DRAFT_ALREADY_EXISTS",
    status_code=400
)

        report = serializer.save(
            user=user,
            status="DRAFT"
        )

        create_activity_log(
            user=user,
            action="REPORT_DRAFT_CREATED",
            action_id=report.id,
            changes={
                "subject_name": user.username,
                "target_title": task.title,
                "reason": f"Draft report for task '{task.title}' was created by {user.username}.",
                "is_by_admin": False
            }
        )
        return report

    @staticmethod
    def update_technical_report_draft(report, serializer, user):
        report = serializer.save()

        create_activity_log(
            user=user,
            action="REPORT_DRAFT_UPDATED",
            action_id=report.id,
            changes={
                "subject_name": user.username,
                "target_title": report.task.title,
                "reason": f"Draft report for task '{report.task.title}' was updated by {user.username}.",
                "is_by_admin": False
            }
        )

        return report


    @staticmethod
    def submit_technical_report(report, user):
        task = report.task

        if task.assigned_to != user:
            raise BaseAppException(
    detail="You can only update your own request.",
    code="REQUEST_UPDATE_NOT_ALLOWED",
    status_code=403
)

        if task.status != "INPROGRESS":
            raise BaseAppException(
    detail="Reports can only be submitted while the task is in progress.",
    code="TASK_NOT_IN_PROGRESS",
    status_code=400
)
        latest_report = task.technical_reports.exclude(id=report.id).order_by("-created_at").first()

        if latest_report:
            if latest_report.status == "SUBMITTED":
                raise ValidationError(
                    "A report is already awaiting manager review."
                )

            if latest_report.status == "APPROVED":
                raise ValidationError(
                    "This task already has an approved report."
                )
        if not report.description:
            raise ValidationError(
                "Description is required before submitting the report."
            )

        report.status = "SUBMITTED"
        report.save(update_fields=["status", "updated_at"])

        task.status = "REVIEW"
        task.save(update_fields=["status", "updated_at"])

        managers = ProjectRole.objects.filter(
            project=task.project,
            role__in=["ADMIN", "MANAGER"]
        ).exclude(user=user).select_related("user")

        for manager_role in managers:
            Notification.objects.create(
                recipient=manager_role.user,
                notification_type="REPORT_SUBMITTED",
                title="New Technical Report Submitted",
                message=(
                    f"Employee {user.get_full_name() or user.username} "
                    f"has submitted a technical report for the task '{task.title}'."
                ),
                navigation_target=f"/task_details/{task.id}"
            )

        create_activity_log(
            user=user,
            action="REPORT_SUBMITTED",
            action_id=report.id,
            changes={
                "subject_name": user.username,
                "target_title": task.title,
                "reason": f"Report for task '{task.title}' was submitted by {user.username}.",
                "is_by_admin": False
            }
        )

        return report

#///////////////////////////////////////////////////////////////////////////////////////////////
class FormService:

    @staticmethod
    def create_request_form(serializer, user):
        request_form = serializer.save(
            user=user,
            status="PENDING"
        )

        managers = ProjectRole.objects.filter(project=request_form.project,role__in=["ADMIN", "MANAGER"]).exclude(user=user).select_related("user")

        for manager_role in managers:
            Notification.objects.create(
                recipient=manager_role.user,
                notification_type="SYSTEM_ALERT",
                title="New Request Submitted",
                message=(
                    f"{user.get_full_name() or user.username} "
                    f"submitted a new request: '{request_form.title}'."),
                navigation_target=f"/requests/{request_form.id}"
            )

        create_activity_log(
            user=user,
            action="REQUEST_CREATED",
            action_id=request_form.id,
            changes={
                "subject_name": user.username,
                "target_title": request_form.title,
                "reason": f"Request '{request_form.title}' was created by {user.username} in project {request_form.project.name}.",
                "is_by_admin": False
            }
        )
        return request_form
    @staticmethod
    def update_request_form(request_form, serializer, user):
        if request_form.user != user:
            raise PermissionDenied(
                "You can only update your own request."
            )

        if request_form.status != "PENDING":
            raise ValidationError(
                "Only pending requests can be updated."
            )
        request_form = serializer.save()

        create_activity_log(
            user=user,
            action="REQUEST_UPDATED",
            action_id=request_form.id,
            changes={
                "subject_name": user.username,
                "target_title": request_form.title,
                "reason": f"Request '{request_form.title}' was updated by {user.username} in project {request_form.project.name}.",
                "is_by_admin": False
            }
        )

        return request_form

    @staticmethod
    def delete_request_form(request_form, user):
        if request_form.user != user:
            raise PermissionDenied(
                "You can only delete your own request."
            )

        if request_form.status != "PENDING":
            raise ValidationError(
                "Only pending requests can be deleted."
            )
        request_id = request_form.id
        request_title = request_form.title
        project_name = request_form.project.name

        create_activity_log(
            user=user,
            action="REQUEST_DELETED",
            action_id=request_id,
            changes={
                "subject_name": user.username,
                "target_title": request_title,
                "reason": f"Request '{request_title}' was deleted by {user.username} in project {project_name}.",
                "is_by_admin": False
            }
        )
        request_form.delete()






    @staticmethod
    @transaction.atomic
    def review_request_form(
        *,
        request_form,
        manager_user,
        status_value,
        manager_feedback=None,
    ):
        is_manager = ProjectRole.objects.filter(
            project=request_form.project,
            user=manager_user,
            role__in=["ADMIN", "MANAGER"],
        ).exists()

        if not is_manager:
            raise PermissionDenied(
                "You are not allowed to review this request."
            )

        allowed_current_statuses = ["PENDING", "ON_HOLD"]

        if request_form.request_type == "LEAVE":
            allowed_current_statuses.append("ACTION_REQUIRED")

        if request_form.status not in allowed_current_statuses:
            raise ValidationError({
                "status": "This request cannot be reviewed in its current status."
            })

        if status_value not in ["APPROVED", "REJECTED", "ON_HOLD"]:
            raise ValidationError({
                "status": (
                    "Status must be APPROVED, REJECTED, or ON_HOLD."
                )
            })

        if request_form.request_type == "LEAVE":
            FormService._validate_leave_review(
                request_form=request_form,
                status_value=status_value,
            )

        request_form.status = status_value

        if manager_feedback is not None:
            request_form.manager_feedback = manager_feedback

        request_form.save(
            update_fields=[
                "status",
                "manager_feedback",
                "updated_at",
            ]
        )

        if request_form.user_id != manager_user.id:
            Notification.objects.create(
                recipient=request_form.user,
                notification_type="SYSTEM_ALERT",
                title="Request Reviewed",
                message=(
                    f"Your request '{request_form.title}' "
                    f"has been {status_value.lower()}."
                ),
                navigation_target=f"/requests/{request_form.id}",
            )

        create_activity_log(
            user=manager_user,
            action="REQUEST_REVIEWED",
            action_id=request_form.id,
            changes={
                "subject_name": manager_user.username,
                "target_title": request_form.title,
                "reason": (
                    f"Request '{request_form.title}' was "
                    f"{status_value.lower()} by "
                    f"{manager_user.username} in project "
                    f"{request_form.project.name}."
                ),
                "is_by_admin": True,
            },
        )

        return request_form

    @staticmethod
    def _validate_leave_review(
        *,
        request_form,
        status_value,
    ):
        if status_value in ["REJECTED", "ON_HOLD"]:
            return

        if status_value != "APPROVED":
            return

        unresolved_actions_exist = LeaveTaskAction.objects.filter(
            request=request_form,
            requires_action=True,
            is_resolved=False,
        ).exists()

        if unresolved_actions_exist:
            raise ValidationError({
                "leave_actions": (
                    "All affected tasks must be resolved "
                    "before approving the leave request."
                )
            })
















































    @staticmethod
    def analyze_task_for_leave(task, leave_request):
        now = timezone.now()

        expected = task.expected_duration or timedelta(0)
        actual = task.actual_duration or timedelta(0)

        remaining = expected - actual

        if remaining < timedelta(0):
            remaining = timedelta(0)

        result = {
            "impact": None,
            "requires_action": False,
            "remaining_duration": remaining,
            "available_duration": None,
            "message": "",
        }

        if task.status == "DONE":
            result.update({
                "impact": "COMPLETED",
                "requires_action": False,
                "message": "Task is already completed.",
            })
            return result

        if not task.due_date:
            result.update({
                "impact": "NO_DUE_DATE",
                "requires_action": True,
                "message": "Task has no due date.",
            })
            return result

        if task.due_date < leave_request.leave_start:
            available_before_leave = max(
                leave_request.leave_start - now,
                timedelta(0),
            )

            can_finish = remaining <= available_before_leave

            result.update({
                "impact": (
                    "CAN_FINISH_BEFORE_LEAVE"
                    if can_finish
                    else "NOT_ENOUGH_TIME_BEFORE_LEAVE"
                ),
                "requires_action": not can_finish,
                "available_duration": available_before_leave,
                "message": (
                    "Task can be completed before leave."
                    if can_finish
                    else "There is not enough time before leave."
                ),
            })

            return result

        if (
            leave_request.leave_start
            <= task.due_date
            <= leave_request.leave_end
        ):
            result.update({
                "impact": "DUE_DURING_LEAVE",
                "requires_action": True,
                "message": "Task is due during the leave period.",
            })

            return result

        available_after_leave = max(
            task.due_date - leave_request.leave_end,
            timedelta(0),
        )

        can_finish_after_return = remaining <= available_after_leave

        result.update({
            "impact": (
                "CAN_FINISH_AFTER_RETURN"
                if can_finish_after_return
                else "NOT_ENOUGH_TIME_AFTER_RETURN"
            ),
            "requires_action": not can_finish_after_return,
            "available_duration": available_after_leave,
            "message": (
                "Task can be completed after returning from leave."
                if can_finish_after_return
                else "There is not enough time after returning from leave."
            ),
        })

        return result

"""
    def analyze_task_for_leave(task, leave_request):
        now = timezone.now()

        expected = task.expected_duration
        actual = task.actual_duration or timezone.timedelta(0)

        remaining = expected - actual
        if remaining.total_seconds() < 0:
            remaining = timezone.timedelta(0)

        if task.status == "DONE":
            return {
                "impact": "COMPLETED",
                "requires_action": False,
                "remaining_duration": remaining,
                "message": "Task is already completed.",
            }

        if task.due_date < leave_request.leave_start:
            available_before_leave = max(
                leave_request.leave_start - now,
                timezone.timedelta(0),
            )

            can_finish = remaining <= available_before_leave

            return {
                "impact": (
                    "CAN_FINISH_BEFORE_LEAVE"
                    if can_finish
                    else "NOT_ENOUGH_TIME_BEFORE_LEAVE"
                ),
                "requires_action": not can_finish,
                "remaining_duration": remaining,
                "available_duration": available_before_leave,
                "message": (
                    "Can be completed before leave."
                    if can_finish
                    else "Not enough time to complete before leave."
                ),
            }

        if leave_request.leave_start <= task.due_date <= leave_request.leave_end:
            return {
                "impact": "DUE_DURING_LEAVE",
                "requires_action": True,
                "remaining_duration": remaining,
                "message": "Task is due during the leave period.",
            }

        available_after_leave = task.due_date - leave_request.leave_end
        can_finish_after_return = remaining <= available_after_leave

        return {
            "impact": (
                "CAN_FINISH_AFTER_RETURN"
                if can_finish_after_return
                else "NOT_ENOUGH_TIME_AFTER_RETURN"
            ),
            "requires_action": not can_finish_after_return,
            "remaining_duration": remaining,
            "available_duration": available_after_leave,
            "message": (
                "Can be completed after returning from leave."
                if can_finish_after_return
                else "Not enough time after returning from leave."
            ),
        }
        """