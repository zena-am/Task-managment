from django.db import transaction
from django.utils import timezone
from rest_framework.exceptions import ValidationError


class LeaveRequestService:

    @staticmethod
    @transaction.atomic
    def resolve_task_action(
        *,
        leave_action,
        manager_user,
        validated_data,
    ):
        task = leave_action.task
        action = validated_data["action"]

        if leave_action.is_resolved:
            raise ValidationError({
                "action": "This leave task action is already resolved."
            })

        if task.status == "DONE":
            raise ValidationError({
                "task": "Completed tasks cannot be modified."
            })

        if action == "TRANSFER_TASK":
            LeaveRequestService._transfer_task(
                leave_action=leave_action,
                task=task,
                manager_user=manager_user,
                new_assignee=validated_data.get("new_assignee"),
            )

        elif action == "EXTEND_DUE_DATE":
            LeaveRequestService._extend_task_due_date(
                leave_action=leave_action,
                task=task,
                new_due_date=validated_data.get("new_due_date"),
            )

        elif action == "PAUSE_TASK":
            LeaveRequestService._pause_task(
                leave_action=leave_action,
                task=task,
            )

        elif action == "NO_ACTION":
            LeaveRequestService._take_no_action(
                leave_action=leave_action,
            )

        else:
            raise ValidationError({
                "action": "Invalid task action."
            })

        leave_action.action = action
        leave_action.is_resolved = True
        leave_action.resolved_by = manager_user
        leave_action.resolved_at = timezone.now()

        leave_action.save(
            update_fields=[
                "action",
                "new_assignee",
                "new_due_date",
                "previous_task_status",
                "is_resolved",
                "resolved_by",
                "resolved_at",
                "updated_at",
            ]
        )

        return leave_action




    @staticmethod
    def _transfer_task(
        *,
        leave_action,
        task,
        manager_user,
        new_assignee,
    ):
        if not new_assignee:
            raise ValidationError({
                "new_assignee": "New assignee is required."
            })

        if task.assigned_to_id == new_assignee.id:
            raise ValidationError({
                "new_assignee": (
                    "The new assignee must be different "
                    "from the current assignee."
                )
            })

        TaskService.assign_task_to_user(
            task=task,
            new_assignee=new_assignee,
            performed_by=manager_user,
            project=task.project,
        )

        leave_action.new_assignee = new_assignee
        leave_action.new_due_date = None




    @staticmethod
    def _extend_task_due_date(
        *,
        leave_action,
        task,
        new_due_date,
    ):
        if not new_due_date:
            raise ValidationError({
                "new_due_date": "New due date is required."
            })

        if task.due_date and new_due_date <= task.due_date:
            raise ValidationError({
                "new_due_date": (
                    "The new due date must be later "
                    "than the current due date."
                )
            })

        task.due_date = new_due_date

        task.save(
            update_fields=[
                "due_date",
                "updated_at",
            ]
        )

        leave_action.new_due_date = new_due_date
        leave_action.new_assignee = None


    @staticmethod
    def _pause_task(
        *,
        leave_action,
        task,
    ):
        if task.status == "PAUSED":
            raise ValidationError({
                "task": "Task is already paused."
            })

        leave_action.previous_task_status = task.status
        leave_action.new_assignee = None
        leave_action.new_due_date = None

        task.status = "PAUSED"

        task.save(
            update_fields=[
                "status",
                "updated_at",
            ]
        )


    @staticmethod
    def _take_no_action(
        *,
        leave_action,
    ):
        leave_action.new_assignee = None
        leave_action.new_due_date = None